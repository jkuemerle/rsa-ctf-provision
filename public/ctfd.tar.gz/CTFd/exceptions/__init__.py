class UserNotFoundException(Exception):
    pass


class UserTokenExpiredException(Exception):
    pass
