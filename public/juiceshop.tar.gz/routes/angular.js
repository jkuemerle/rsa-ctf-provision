const path = require('path')
const utils = require('../lib/utils')

module.exports = function serveAngularClient () {
  return ({ url }, res, next) => {
    if (!utils.startsWith(url, '/api') && !utils.startsWith(url, '/rest')) {
      // res.sendFile(path.resolve(__dirname, '../app/index.html'))
      res.sendFile(path.resolve(__dirname, '../frontend/dist/frontend/index.html'))
    } else {
      next(new Error('Unexpected path: ' + url))
    }
  }
}
